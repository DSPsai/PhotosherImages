const { Builder, Browser, By, Key, until } = require('selenium-webdriver');
var webdriver = require('selenium-webdriver');
const download = require('download')
var fs = require('fs');
async function example() {
    // var chromeCapabilities = webdriver.Capabilities.chrome();

    // // add the desired options
    // var chromeOptions = { 'args': ['--test-type', '--incognito'] };
    // chromeCapabilities.set('chromeOptions', chromeOptions);

    var driver = await new Builder().forBrowser('chrome').build();
    // var driver = await new Builder().withCapabilities(chromeCapabilities).build();
    var url = 'http://localhost:3000/'


    var csrf = '3T11LHaECPciKgGwsGT2vtQ5G5DgEzuwpmUwu85ZmuGSLlMXozFECIIBW09K8GIa'
    var sessionid = 'h4w8khvmofjf0gzjgqe35f9yykkpq7ix'

    // let csrf='jZyv5q7BrZAynIgnrRsKelhECmZBdKnITG3k6qKZSVwVsqqQYCQ6BoP0l93Y3yC8'

    // let csrf='jZyv5q7BrZAynIgnrRsKelhECmZBdKnITG3k6qKZSVwVsqqQYCQ6BoP0l93Y3yC8'
    try {
        const setPlansAssets = async () => {
            await driver.get('https://photosher.com/admin/'); // url of website to be tested on
            await driver.manage().deleteAllCookies();
            await driver.manage().addCookie({ name: 'set-cookie', value: 'undefined' });
            await driver.manage().addCookie({ name: 'csrftoken', value: csrf });
            await driver.manage().addCookie({ name: 'sessionid', value: sessionid });

            const setPlans = async () => {
                await driver.get('https://photosher.com/admin/client/product_prizes/add/'); // url of website to be tested on
                const planData = [
                    [
                        {
                            cpi: '2',
                            name: 'basic editing',
                            enhancement: '7',
                            list: [
                                'Single Raw Edit',
                                'Color correction',
                                'Lens corrections',
                                'Lens corrections',
                                'Blemish Removal',
                                'Chromatic Abberation',
                                'Brightness and Contrast adjustments',
                            ],
                            img: 'https://images.pexels.com/photos/1329711/pexels-photo-1329711.jpeg?auto=compress&cs=tinysrgb&w=500'
                        }, {
                            cpi: '4',
                            name: 'basic plus',
                            enhancement: '10',
                            list: [
                                'Single Raw Edit',
                                'Color correction',
                                'Lens corrections',
                                'Lens corrections',
                                'Blemish Removal',
                                'Chromatic Abberation',
                                'Brightness and Contrast adjustments',
                                'Blemish Removal',
                                'Chromatic Abberation',
                                'Brightness and Contrast adjustments',
                            ],
                            img: 'https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg?auto=compress&cs=tinysrgb&w=500'
                        }, {
                            cpi: '8',
                            name: 'standerd',
                            enhancement: '14',
                            list: [
                                'Single Raw Edit',
                                'Color correction',
                                'Lens corrections',
                                'Lens corrections',
                                'Blemish Removal',
                                'Chromatic Abberation',
                                'Brightness and Contrast adjustments',
                                'Single Raw Edit',
                                'Color correction',
                                'Lens corrections',
                                'Lens corrections',
                                'Blemish Removal',
                                'Chromatic Abberation',
                                'Brightness and Contrast adjustments',
                            ],
                            img: 'https://images.pexels.com/photos/271624/pexels-photo-271624.jpeg?auto=compress&cs=tinysrgb&w=500'
                        }, {
                            cpi: '12',
                            name: 'advanced',
                            enhancement: '18',
                            list: [
                                'Single Raw Edit',
                                'Color correction',
                                'Lens corrections',
                                'Lens corrections',
                                'Blemish Removal',
                                'Chromatic Abberation',
                                'Brightness and Contrast adjustments',
                                'Single Raw Edit',
                                'Color correction',
                                'Lens corrections',
                                'Lens corrections',
                                'Blemish Removal',
                                'Chromatic Abberation',
                                'Brightness and Contrast adjustments',
                                'Lens corrections',
                                'Blemish Removal',
                                'Chromatic Abberation',
                                'Brightness and Contrast adjustments',
                            ],
                            img: 'https://images.pexels.com/photos/1095127/pexels-photo-1095127.jpeg?auto=compress&cs=tinysrgb&w=500'
                        },
                    ], [
                        {
                            cpi: '2',
                            name: 'basic editing',
                            enhancement: '7',
                            list: [
                                'Single Raw Edit',
                                'Color correction',
                                'Lens corrections',
                                'Lens corrections',
                                'Blemish Removal',
                                'Chromatic Abberation',
                                'Brightness and Contrast adjustments',
                            ],
                            img: 'https://images.pexels.com/photos/1329711/pexels-photo-1329711.jpeg?auto=compress&cs=tinysrgb&w=500'
                        }, {
                            cpi: '4',
                            name: 'basic plus',
                            enhancement: '10',
                            list: [
                                'Single Raw Edit',
                                'Color correction',
                                'Lens corrections',
                                'Lens corrections',
                                'Blemish Removal',
                                'Chromatic Abberation',
                                'Brightness and Contrast adjustments',
                                'Blemish Removal',
                                'Chromatic Abberation',
                                'Brightness and Contrast adjustments',
                            ],
                            img: 'https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg?auto=compress&cs=tinysrgb&w=500'
                        }, {
                            cpi: '8',
                            name: 'standerd',
                            enhancement: '14',
                            list: [
                                'Single Raw Edit',
                                'Color correction',
                                'Lens corrections',
                                'Lens corrections',
                                'Blemish Removal',
                                'Chromatic Abberation',
                                'Brightness and Contrast adjustments',
                                'Single Raw Edit',
                                'Color correction',
                                'Lens corrections',
                                'Lens corrections',
                                'Blemish Removal',
                                'Chromatic Abberation',
                                'Brightness and Contrast adjustments',
                            ],
                            img: 'https://images.pexels.com/photos/271624/pexels-photo-271624.jpeg?auto=compress&cs=tinysrgb&w=500'
                        }, {
                            cpi: '12',
                            name: 'advanced',
                            enhancement: '18',
                            list: [
                                'Single Raw Edit',
                                'Color correction',
                                'Lens corrections',
                                'Lens corrections',
                                'Blemish Removal',
                                'Chromatic Abberation',
                                'Brightness and Contrast adjustments',
                                'Single Raw Edit',
                                'Color correction',
                                'Lens corrections',
                                'Lens corrections',
                                'Blemish Removal',
                                'Chromatic Abberation',
                                'Brightness and Contrast adjustments',
                                'Lens corrections',
                                'Blemish Removal',
                                'Chromatic Abberation',
                                'Brightness and Contrast adjustments',
                            ],
                            img: 'https://images.pexels.com/photos/1095127/pexels-photo-1095127.jpeg?auto=compress&cs=tinysrgb&w=500'
                        }, {
                            cpi: '2',
                            name: 'basic editing',
                            enhancement: '7',
                            list: [
                                'Single Raw Edit',
                                'Color correction',
                                'Lens corrections',
                                'Lens corrections',
                                'Blemish Removal',
                                'Chromatic Abberation',
                                'Brightness and Contrast adjustments',
                            ],
                            img: 'https://images.pexels.com/photos/1329711/pexels-photo-1329711.jpeg?auto=compress&cs=tinysrgb&w=500'
                        }, {
                            cpi: '4',
                            name: 'basic plus',
                            enhancement: '10',
                            list: [
                                'Single Raw Edit',
                                'Color correction',
                                'Lens corrections',
                                'Lens corrections',
                                'Blemish Removal',
                                'Chromatic Abberation',
                                'Brightness and Contrast adjustments',
                                'Blemish Removal',
                                'Chromatic Abberation',
                                'Brightness and Contrast adjustments',
                            ],
                            img: 'https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg?auto=compress&cs=tinysrgb&w=500'
                        }, {
                            cpi: '8',
                            name: 'standerd',
                            enhancement: '14',
                            list: [
                                'Single Raw Edit',
                                'Color correction',
                                'Lens corrections',
                                'Lens corrections',
                                'Blemish Removal',
                                'Chromatic Abberation',
                                'Brightness and Contrast adjustments',
                                'Single Raw Edit',
                                'Color correction',
                                'Lens corrections',
                                'Lens corrections',
                                'Blemish Removal',
                                'Chromatic Abberation',
                                'Brightness and Contrast adjustments',
                            ],
                            img: 'https://images.pexels.com/photos/271624/pexels-photo-271624.jpeg?auto=compress&cs=tinysrgb&w=500'
                        }, {
                            cpi: '12',
                            name: 'advanced',
                            enhancement: '18',
                            list: [
                                'Single Raw Edit',
                                'Color correction',
                                'Lens corrections',
                                'Lens corrections',
                                'Blemish Removal',
                                'Chromatic Abberation',
                                'Brightness and Contrast adjustments',
                                'Single Raw Edit',
                                'Color correction',
                                'Lens corrections',
                                'Lens corrections',
                                'Blemish Removal',
                                'Chromatic Abberation',
                                'Brightness and Contrast adjustments',
                                'Lens corrections',
                                'Blemish Removal',
                                'Chromatic Abberation',
                                'Brightness and Contrast adjustments',
                            ],
                            img: 'https://images.pexels.com/photos/1095127/pexels-photo-1095127.jpeg?auto=compress&cs=tinysrgb&w=500'
                        },
                    ], [
                        {
                            cpi: '2',
                            name: 'basic editing',
                            enhancement: '7',
                            list: [
                                'Single Raw Edit',
                                'Color correction',
                                'Lens corrections',
                                'Lens corrections',
                                'Blemish Removal',
                                'Chromatic Abberation',
                                'Brightness and Contrast adjustments',
                            ],
                            img: 'https://images.pexels.com/photos/1329711/pexels-photo-1329711.jpeg?auto=compress&cs=tinysrgb&w=500'
                        }, {
                            cpi: '4',
                            name: 'basic plus',
                            enhancement: '10',
                            list: [
                                'Single Raw Edit',
                                'Color correction',
                                'Lens corrections',
                                'Lens corrections',
                                'Blemish Removal',
                                'Chromatic Abberation',
                                'Brightness and Contrast adjustments',
                                'Blemish Removal',
                                'Chromatic Abberation',
                                'Brightness and Contrast adjustments',
                            ],
                            img: 'https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg?auto=compress&cs=tinysrgb&w=500'
                        },
                    ]
                ]
                const tabs = [
                    'photo editing',
                    'photoshop edits',
                    'video editing'
                ]
                for (let i = 0; i < tabs.length; i++) {
                    for (let j of planData[i]) {
                        await download(j.img, 'files', { filename: 'file_name.jpeg' }).then(async () => {
                            await driver.findElement(By.id('id_services')).sendKeys(tabs[i]);
                            await driver.findElement(By.id('id_Product')).sendKeys(j.name);
                            await driver.findElement(By.id('id_prizes')).sendKeys(j.cpi);
                            await driver.findElement(By.id('id_text_content')).sendKeys(j.list.join('\n'));
                            await driver.findElement(By.id('id_image')).sendKeys(__dirname + "/files/file_name.jpeg");
                            await driver.findElement(By.name('_addanother')).sendKeys(Key.ENTER);
                        })
                    }
                }
                console.log('Plans Added')

            }

            await setPlans()

            const setAssets = async () => {
                await driver.get('https://photosher.com/admin/client/assets/add/'); // url of website to be tested on
                let folders = ['Fire', 'Sky', 'Tv']
                for (let i = 0; i < folders.length; i++) {
                    var files = fs.readdirSync('Assets/' + folders[i]);
                    console.log(files)
                    for (let j of files) {
                        await driver.findElement(By.id('id_image')).sendKeys(__dirname + '/Assets/' + folders[i] + '/' + j);
                        await driver.findElement(By.id('id_label')).sendKeys(Key.SHIFT, Key.HOME, Key.BACK_SPACE);
                        await driver.findElement(By.id('id_label')).sendKeys(folders[i]);
                        await driver.findElement(By.id('id_default')).click();
                        await driver.findElement(By.name('_addanother')).sendKeys(Key.ENTER);
                    }
                }
            }
            await setAssets()

        }
        const createProjectPhoto = async () => {
            await driver.get(url + '/SignIn'); // url of website to be tested on
            await driver.executeScript(function () {
                localStorage.setItem("access", 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ0b2tlbl90eXBlIjoiYWNjZXNzIiwiZXhwIjoxNjc0NDUyODYxLCJqdGkiOiJmMmYxNWEyMTZkNjA0NTlmOTM1N2RhZTQzZDQ4NjZkMyIsInVzZXJfaWQiOjF9.C9SESJVOJZBb2j_9sY1hoS1kB3oalY4Ffp19R-dqgcs');
            });
            await driver.get(url + 'Dashboard/CreateProject/ProductDetails/PhotoEdit'); // url of website to be tested on
            setTimeout(async () => {
                await driver.findElement(By.id('plan0')).click();
                await driver.findElement(By.id('projectName')).sendKeys('Project Namer');
                await driver.findElement(By.id('projectPhotoNumber')).sendKeys('4');
                let attachs = []
                var files = fs.readdirSync('Assets/Sky');
                for (let i of files) {
                    // attachs.push(`${__dirname + '/Assets/Sky/' + i}`)
                    attachs.push(`${__dirname + '/Assets/Sky/' + i}`);
                }
                await driver.findElement(By.name('FileDragUploader')).sendKeys(attachs.join(' \n'))
                let tabs = ['Fire', 'Sky', 'Tv']
                for (let i of tabs) {
                    await driver.findElement(By.id(i)).click();
                    await driver.findElement(By.className('center')).click()
                    await driver.findElement(By.id('asset0')).click();
                }
                await driver.findElement(By.id('userName' + i)).sendKeys('User0');
                await driver.findElement(By.id('userMail' + i)).sendKeys('user0@gmail.com');
                for (let i = 1; i < 3; i++) {
                    await driver.findElement(By.id('addUser')).click();
                    await driver.findElement(By.id('userName' + i)).sendKeys('User' + i);
                    await driver.findElement(By.id('userMail' + i)).sendKeys('user' + i + '@gmail.com');
                }
                await driver.findElement(By.id('next')).click();
            }, 3000)
        }
        // createProjectPhoto().then(asd => console.log(asd)).catch(er => console.log(er))1E90FF
        const iithAddCourse = async () => {
            let list = [
                {
                    name: 'Basic Electrical Engineering',
                    Fee: '20',
                    img: 'Assets/Tv/nature.jpg',
                    cred: '3',
                    desc: 'This basic electric engineering course is common to first-year branches of studying. At the end of the course the student is expected to know the fundamental of electrical engineering as well as the practical implementation of fundamental theory concepts.',
                    link: 'https://youtube.com/playlist?list=PL-uxPiMl0_6FdWDwfwOot7-l1qYtJHrUZ'
                }, {
                    name: 'Power Systems',
                    Fee: '20',
                    img: 'Assets/Tv/wild 06.jpg',
                    cred: '3',
                    desc: "Power System Engineering is an undergraduate Power System Engineering course. This program, at the intersection of electric power, economics and management, prepares professionals in power generation, transmission and distribution, and power equipment. The students can also switch over to other specializations like energy conservation, renewable energy engineering, sustainable development. The course deals with the generation, transmission and distribution of electric power as well as the electrical devices connected to such systems including generators, motors and transformers.",
                    link: 'https://youtube.com/playlist?list=PL-uxPiMl0_6FPrEBGS4EwFBK5WMosImyq'
                }, {
                    name: 'Smart Grids',
                    Fee: '20',
                    img: 'Assets/Tv/wild 07.jpg',
                    cred: '1',
                    desc: "course in smart electric grid helps graduates get jobs in renewable energy-based companies. These professionals will find a wide range of opportunities in engineering development and design. Additionally, they can look forward to working in smart-grid industries, as well as in consultancy.",
                    link: 'https://youtube.com/playlist?list=PL-uxPiMl0_6EUC-bpfsG1y0wVo4swKyUo'
                }, {
                    name: 'Magnetic Circuits',
                    Fee: '20',
                    img: 'Assets/Tv/wild 05.jpg',
                    cred: '3',
                    desc: "This module will focus on the magnetic circuit and the magnetic properties of materials. The student will learn the principles of magnetic force, reluctance, permeance, and permeability. Ampere's circuit law is also discussed as well as design considerations for air gaps in magnetic circuits. This module also introduces the student to the effects of magnetic hysteresis and residual magnetism on a magnetic circuit.",
                    link: 'https://youtube.com/playlist?list=PL-uxPiMl0_6GUK5mREXy-zx2OUnG8oxsz'
                },
            ]
            let data = []
            await driver.get('https://powersense.co.in/admin/login/?next=/admin/'); // url of website to be tested on
            await driver.manage().addCookie({ name: 'set-cookie', value: 'undefined' });
            await driver.manage().addCookie({ name: 'csrftoken', value: csrf });

            await driver.manage().addCookie({ name: 'sessionid', value: sessionid })
            // await driver.get('https://powersense.co.in/admin/main/courses/add/'); // url of website to be tested on
            // for (let playlist of list) {
            //     await driver.findElement(By.id('id_titlecard')).sendKeys(__dirname + '/' + playlist.img);
            //     await driver.findElement(By.id('id_name')).sendKeys(Key.SHIFT, Key.END, Key.BACK_SPACE);
            //     await driver.findElement(By.id('id_name')).sendKeys(playlist.name);
            //     await driver.findElement(By.id('id_Fee')).sendKeys(playlist.Fee);
            //     await driver.findElement(By.id('id_description')).sendKeys(playlist.desc);
            //     await driver.findElement(By.id('id_credits')).sendKeys(playlist.cred);
            //     await driver.findElement(By.name('_addanother')).sendKeys(Key.ENTER);
            // }
            var c = 7;
            for (let playlist of list) {
                await driver.get(playlist.link); // url of website to be tested on
                let imgs = await driver.findElements(By.className('yt-core-image'))
                let names = await driver.findElements(By.css('#video-title.ytd-playlist-video-renderer'))
                let time = await driver.findElements(By.css('#text.ytd-thumbnail-overlay-time-status-renderer'))
                let tdata = []
                await driver.executeScript(`
                        window.scrollTo({top:10000,left:0,behavior:'smooth'})
                        `)
                // setTimeout(async () => {
                let n = imgs.length
                for (let i = 0; i < n; i++) {
                    let tlis = {}
                    await imgs[i].getAttribute('src').then(asd => {
                        tlis["img"] = asd
                    })
                    await names[i].getAttribute('title').then(asd => {
                        tlis["name"] = asd
                    })
                    await names[i].getAttribute('href').then(asd => {
                        tlis["link"] = asd
                    })
                    await time[i].getText().then(asd => {
                        tlis["time"] = asd
                    })
                    tdata.push(tlis)
                }
                console.log(tdata)
                await driver.get('https://powersense.co.in/admin/main/play_list/add/'); // url of website to be tested on
                await driver.findElement(By.id('id_courses')).sendKeys(c);
                await driver.findElement(By.id('id_links')).sendKeys(Key.SHIFT, Key.HOME, Key.BACK_SPACE);
                await driver.executeScript(`
                document.getElementById('id_courses').value=${c}
                `, c)
                await driver.executeScript(`
                document.getElementById('id_links').value=\`{ "data": ${JSON.stringify(tdata)} }\`
                `, c)
                // await driver.findElement(By.id('id_links')).sendKeys(
                //     `{ "data": ${JSON.stringify(tdata)} }`
                // );
                await driver.findElement(By.name('_save')).sendKeys(Key.ENTER);
                c += 1
            }
        }
        // await setData()
        // await iithAddCourse()

        // await driver.manage().addCookie({ name: 'set-cookie', value: 'undefined' });
        // await driver.manage().addCookie({ name: 'csrftoken', value: csrf });
        // await driver.manage().addCookie({ name: 'sessionid', value: sessionid });

        const setPackagesPhotosher = async () => {
            await driver.get('https://photosher.com/admin/'); // url of website to be tested on
            await driver.manage().deleteAllCookies();
            await driver.manage().addCookie({ name: 'set-cookie', value: 'undefined' });
            await driver.manage().addCookie({ name: 'csrftoken', value: csrf });
            await driver.manage().addCookie({ name: 'sessionid', value: sessionid });

            var plandat = {
                features_schema: [
                    'Extra Credits',
                    'Revisions',
                    'Video Editing',
                    'Free 18 Hours Turnaround Time',
                    'Priority Support',
                    'Unlimited File Size',
                ],
                starter:
                    [
                        {
                            price: '0$ - 500$',
                            cred: '0 - 500',
                            plans: [
                                {
                                    name: 'Package 01',
                                    price: '100',
                                    text: 'For those users who like to save money and does limited work. For those who trust us and know the value of being regular user',
                                    features1: [
                                        'Advanced admin controls',
                                        'Domain Verification',
                                        'Message exports',
                                    ],
                                    features2: [
                                        false, '4 Hour Revisions', false, false, false, false
                                    ]
                                }, {
                                    name: 'Package 02', price: '300', text: 'For those users who like to save money and does limited work. For those who trust us and know the value of being regular user',
                                    features1: [
                                        'Advanced admin controls',
                                        'Domain Verification',
                                        'Message exports',
                                    ],
                                    features2: [
                                        '1000 Credits', '4 Hour Revisions', true, true, true, true
                                    ]
                                }, {
                                    name: 'Package 03', price: '499', text: 'For those users who like to save money and does limited work. For those who trust us and know the value of being regular user',
                                    features1: [
                                        'Advanced admin controls',
                                        'Domain Verification',
                                        'Message exports',
                                    ],
                                    features2: [
                                        '3000 Credits', '12 Hour Revisions', true, true, true, true
                                    ]
                                }
                            ]
                        }, {
                            price: '501$ - 1000$',
                            cred: '501 - 1000',
                            plans: [
                                {
                                    name: 'Package 01', price: '501', text: 'For those users who like to save money and does limited work. For those who trust us and know the value of being regular user',
                                    features1: [
                                        'Advanced admin controls',
                                        'Domain Verification',
                                        'Message exports',
                                    ],
                                    features2: [
                                        false, '4 Hour Revisions', false, false, false, false
                                    ]
                                }, {
                                    name: 'Package 02', price: '750', text: 'For those users who like to save money and does limited work. For those who trust us and know the value of being regular user',
                                    features1: [
                                        'Advanced admin controls',
                                        'Domain Verification',
                                        'Message exports',
                                    ],
                                    features2: [
                                        '1000 Credits', '4 Hour Revisions', true, true, true, true
                                    ]
                                }, {
                                    name: 'Package 03', price: '999', text: 'For those users who like to save money and does limited work. For those who trust us and know the value of being regular user',
                                    features1: [
                                        'Advanced admin controls',
                                        'Domain Verification',
                                        'Message exports',
                                    ],
                                    features2: [
                                        '3000 Credits', '12 Hour Revisions', true, true, true, true
                                    ]
                                }
                            ]
                        }, {
                            price: '1001$ - 1500$',
                            cred: '1001 - 1500',
                            plans: [
                                {
                                    name: 'Package 01', price: '1001', text: 'For those users who like to save money and does limited work. For those who trust us and know the value of being regular user',
                                    features1: [
                                        'Advanced admin controls',
                                        'Domain Verification',
                                        'Message exports',
                                    ],
                                    features2: [
                                        false, '4 Hour Revisions', false, false, false, false
                                    ]
                                }, {
                                    name: 'Package 02', price: '1250', text: 'For those users who like to save money and does limited work. For those who trust us and know the value of being regular user',
                                    features1: [
                                        'Advanced admin controls',
                                        'Domain Verification',
                                        'Message exports',
                                    ],
                                    features2: [
                                        '1000 Credits', '4 Hour Revisions', true, true, true, true
                                    ]
                                }, {
                                    name: 'Package 03', price: '1499', text: 'For those users who like to save money and does limited work. For those who trust us and know the value of being regular user',
                                    features1: [
                                        'Advanced admin controls',
                                        'Domain Verification',
                                        'Message exports',
                                    ],
                                    features2: [
                                        '3000 Credits', '12 Hour Revisions', true, true, true, true
                                    ]
                                }
                            ]
                        }, {
                            price: '1501$ - 2000$',
                            cred: '1501 - 2000',
                            plans: [
                                {
                                    name: 'Package 01', price: '1501', text: 'For those users who like to save money and does limited work. For those who trust us and know the value of being regular user',
                                    features1: [
                                        'Advanced admin controls',
                                        'Domain Verification',
                                        'Message exports',
                                    ],
                                    features2: [
                                        false, '4 Hour Revisions', false, false, false, false
                                    ]
                                }, {
                                    name: 'Package 02', price: '1750', text: 'For those users who like to save money and does limited work. For those who trust us and know the value of being regular user',
                                    features1: [
                                        'Advanced admin controls',
                                        'Domain Verification',
                                        'Message exports',
                                    ],
                                    features2: [
                                        '1000 Credits', '4 Hour Revisions', true, true, true, true
                                    ]
                                }, {
                                    name: 'Package 03', price: '1999', text: 'For those users who like to save money and does limited work. For those who trust us and know the value of being regular user',
                                    features1: [
                                        'Advanced admin controls',
                                        'Domain Verification',
                                        'Message exports',
                                    ],
                                    features2: [
                                        '3000 Credits', '12 Hour Revisions', true, true, true, true
                                    ]
                                }
                            ]
                        }, {
                            price: '2001$ - 2500$',
                            cred: '2001 - 2500',
                            plans: [
                                {
                                    name: 'Package 01', price: '2001', text: 'For those users who like to save money and does limited work. For those who trust us and know the value of being regular user',
                                    features1: [
                                        'Advanced admin controls',
                                        'Domain Verification',
                                        'Message exports',
                                    ],
                                    features2: [
                                        false, '4 Hour Revisions', false, false, false, false
                                    ]
                                }, {
                                    name: 'Package 02', price: '2250', text: 'For those users who like to save money and does limited work. For those who trust us and know the value of being regular user',
                                    features1: [
                                        'Advanced admin controls',
                                        'Domain Verification',
                                        'Message exports',
                                    ],
                                    features2: [
                                        '1000 Credits', '4 Hour Revisions', true, true, true, true
                                    ]
                                }, {
                                    name: 'Package 03', price: '2499', text: 'For those users who like to save money and does limited work. For those who trust us and know the value of being regular user',
                                    features1: [
                                        'Advanced admin controls',
                                        'Domain Verification',
                                        'Message exports',
                                    ],
                                    features2: [
                                        '3000 Credits', '12 Hour Revisions', true, true, true, true
                                    ]
                                }
                            ]
                        },
                    ],
                professional: [
                    {
                        price: '2001$ - 2500$',
                        cred: '2001 - 2500',
                        plans: [
                            {
                                name: 'Lite', price: '357', cutprice: '2501', discount: '25',
                                text: 'For those users who like to save money and does limited work. For those who trust us and know the value of being regular user',
                                features1: [
                                    'Advanced admin controls',
                                    'Domain Verification',
                                    'Message exports',
                                ],
                                features2: [
                                    '500 Credits', '4 Hour Revisions', true, false, false, true
                                ]
                            }, {
                                name: 'Standard', price: '675', discount: '25', cutprice: '2750', text: 'For those users who like to save money and does limited work. For those who trust us and know the value of being regular user',
                                features1: [
                                    'Advanced admin controls',
                                    'Domain Verification',
                                    'Message exports',
                                ],
                                features2: [
                                    '1000 Credits', '8 Hour Revisions', true, true, true, true
                                ]
                            }, {
                                name: 'Advance', price: '1913', discount: '25', cutprice: '2999', text: 'For those users who like to save money and does limited work. For those who trust us and know the value of being regular user',
                                features1: [
                                    'Advanced admin controls',
                                    'Domain Verification',
                                    'Message exports',
                                ],
                                features2: [
                                    '3000 Credits', '12 Hour Revisions', true, true, true, true
                                ]
                            }
                        ]
                    },
                ]
            }
            await driver.get('https://photosher.com/admin/client/packages_objects/add/'); // url of website to be tested on
            const setStarters = async () => {
                for (let i of plandat.starter) {
                    for (let j of i.plans) {
                        await driver.findElement(By.name('package_name')).sendKeys(j.name);
                        await driver.findElement(By.name('prize')).sendKeys(Key.SHIFT, Key.HOME, Key.BACK_SPACE);
                        await driver.findElement(By.name('prize')).sendKeys(parseInt(j.price));
                        await driver.findElement(By.name('descptionn')).sendKeys(j.text);
                        await driver.findElement(By.name('feauters')).sendKeys(Key.SHIFT, Key.HOME, Key.BACK_SPACE);
                        let tp = {}
                        j.features1.map(dat => {
                            tp[dat] = 'True'
                        })
                        await driver.findElement(By.name('feauters')).sendKeys(JSON.stringify(tp));
                        await driver.findElement(By.name('extra_feautures_descption')).sendKeys(Key.SHIFT, Key.HOME, Key.BACK_SPACE);
                        tp = {}
                        plandat.features_schema.map((dat, ind) => {
                            tp[dat] = j.features2[ind] === true ? 'True' : j.features2[ind] === false ? 'False' : j.features2[ind]
                        })
                        await driver.findElement(By.name('extra_feautures_descption')).sendKeys(JSON.stringify(tp));
                        await driver.findElement(By.name('_addanother')).sendKeys(Key.ENTER);
                    }
                }
            }
            const setProfessionals = async () => {
                for (let i of plandat.professional) {
                    for (let j of i.plans) {
                        await driver.findElement(By.name('package_name')).sendKeys(j.name);
                        await driver.findElement(By.name('prize')).sendKeys(Key.CONTROL, 'a', Key.BACK_SPACE);
                        await driver.findElement(By.name('prize')).sendKeys(j.cutprice);
                        // await driver.findElement(By.name('prize')).sendKeys(Key.BACK_SPACE);
                        await driver.findElement(By.name('descptionn')).sendKeys(j.text);
                        await driver.findElement(By.name('feauters')).sendKeys(Key.SHIFT, Key.HOME, Key.BACK_SPACE);
                        let tp = {}
                        j.features1.map(dat => {
                            tp[dat] = 'True'
                        })
                        await driver.findElement(By.name('feauters')).sendKeys(JSON.stringify(tp));
                        await driver.findElement(By.name('extra_feautures_descption')).sendKeys(Key.SHIFT, Key.HOME, Key.BACK_SPACE);
                        tp = {}
                        plandat.features_schema.map((dat, ind) => {
                            tp[dat] = j.features2[ind] === true ? 'True' : j.features2[ind] === false ? 'False' : j.features2[ind]
                        })
                        await driver.findElement(By.name('extra_feautures_descption')).sendKeys(JSON.stringify(tp));
                        await driver.findElement(By.name('discount')).sendKeys(Key.CONTROL, 'a', Key.BACK_SPACE);
                        await driver.findElement(By.name('discount')).sendKeys(j.discount);
                        console.log('The actual values are  ', j.discount, j.cutprice)
                        // await driver.findElement(By.name('discount')).sendKeys(Key.BACK_SPACE);
                        await driver.findElement(By.name('profesional')).click();
                        // await driver.findElement(By.name('_addanother')).sendKeys(Key.ENTER);
                    }
                }
            }
            await setStarters()
            await setProfessionals()
        }
        await setPlansAssets()
        await setPackagesPhotosher()
    } catch (er) {
        console.log(er)
    } finally {
        // await driver.quit();
    }
};
example()